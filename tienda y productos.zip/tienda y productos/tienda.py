class Tienda:
    def __init__(self, nombre):
        self.nombre = nombre
        self.productos = []
    def agregar_producto(self, nuevo_producto):
        self.productos.append(nuevo_producto)
    def vender_producto(self, id):
        for producto in self.productos:
            if producto.id == id:
                self.productos.remove(producto)
                producto.print_info()
                break
        else:
            print("Producto no encontrado.")
    def inflación(self, porcentaje_aumento):
        for producto in self.productos:
            producto.actualizar_precio(porcentaje_aumento, True)
    def hacer_liquidación(self, categoria, porcentaje_descuento):
        for producto in self.productos:
            if producto.categoria == categoria:
                producto.actualizar_precio(porcentaje_descuento, False)
