from producto import Producto
from tienda import Tienda

mi_tienda = Tienda("Mi Tienda")

producto1 = Producto("Camiseta", 20.0, "Ropa")
producto2 = Producto("Zapatos", 50.0, "Calzado")
producto3 = Producto("Libro", 15.0, "Libros")

mi_tienda.agregar_producto(producto1)
mi_tienda.agregar_producto(producto2)
mi_tienda.agregar_producto(producto3)

print("Productos en la tienda:")
for producto in mi_tienda.productos:
    producto.print_info()
    print("")

print("Vendiendo un producto:")
mi_tienda.vender_producto(1)
print("Actualizando el precio de un producto:")
producto1.actualizar_precio(10, True)

print("Información del producto actualizado:")
producto1.print_info()

print("Aplicando inflación a todos los productos:")
mi_tienda.inflación(5)

print("Haciendo liquidación en la categoría 'Ropa':")
mi_tienda.hacer_liquidación("Ropa", 20)

print("Productos actualizados en la tienda:")
for producto in mi_tienda.productos:
    producto.print_info()
    print("")
